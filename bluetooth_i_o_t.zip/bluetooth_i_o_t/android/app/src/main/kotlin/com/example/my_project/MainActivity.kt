package com.mycompany.bluetoothiot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/splash_page/splash_page_widget.dart' show SplashPageWidget;
export '/pages/device_page/device_page_widget.dart' show DevicePageWidget;
export '/pages/settings_page/settings_page_widget.dart' show SettingsPageWidget;
export '/pages/notifications_page/notifications_page_widget.dart'
    show NotificationsPageWidget;
export '/pages/privacy_policy/privacy_policy_widget.dart'
    show PrivacyPolicyWidget;
export '/pages/getting_started/getting_started_widget.dart'
    show GettingStartedWidget;
export '/pages/about_us/about_us_widget.dart' show AboutUsWidget;

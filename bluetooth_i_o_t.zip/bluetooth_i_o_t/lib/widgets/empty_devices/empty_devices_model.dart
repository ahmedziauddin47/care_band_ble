import '/flutter_flow/flutter_flow_util.dart';
import 'empty_devices_widget.dart' show EmptyDevicesWidget;
import 'package:flutter/material.dart';

class EmptyDevicesModel extends FlutterFlowModel<EmptyDevicesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}

import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'getting_started_model.dart';
export 'getting_started_model.dart';

class GettingStartedWidget extends StatefulWidget {
  const GettingStartedWidget({super.key});

  @override
  State<GettingStartedWidget> createState() => _GettingStartedWidgetState();
}

class _GettingStartedWidgetState extends State<GettingStartedWidget> {
  late GettingStartedModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GettingStartedModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: FlutterFlowTheme.of(context).primaryText,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Getting Started',
            style: FlutterFlowTheme.of(context).bodyLarge.override(
                  fontFamily: 'Montserrat',
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: false,
          elevation: 0.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 240.0,
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(0.0),
                      child: Image.network(
                        'https://picsum.photos/seed/669/600',
                        width: double.infinity,
                        height: 200.0,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: Text(
                  'CareBand User Manual',
                  style: FlutterFlowTheme.of(context).headlineMedium.override(
                        fontFamily: 'Montserrat',
                        letterSpacing: 0.0,
                      ),
                ),
              ),
              Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                child: Text(
                  'Congratulations on your purchase of the CareBand Microcontroller Health Monitor! This user manual will guide you through the simple steps to set up and use your device effectively.\n\nStep 1: Download the CareBandWeb App\n\nThe first step is to download the CareBandWeb app on your smartphone. You can find the app on the App Store for iOS devices or Google Play Store for Android devices. Simply search for \"CareBandWeb\" and follow the instructions to download and install the app on your device.\n\nStep 2: Connect the Battery\n\nNext, connect the battery to your CareBand Microcontroller Health Monitor device. Ensure that the battery is securely connected and properly inserted into the device.\n\nStep 3: Power On the Device\n\nOnce the battery is connected, the device will power on automatically. Look for the indicator light on the device. If the light turns on, it means the device is powered on and ready to use.\n\nStep 4: Open the CareBandWeb App\n\nNow, open the CareBandWeb app on your smartphone. The app will automatically scan for Bluetooth devices in range.\n\nStep 5: Connect to Your Device\n\nOnce the scanning is complete, look for the CareBandWeb device in the list of available devices on the app. Tap on the device to connect it to your smartphone.\n\nStep 6: Congratulations! Your Device is Connected\n\nYou have successfully connected your CareBand Microcontroller Health Monitor device to the CareBandWeb app. Congratulations! Your device is now ready to use.\n\nStep 7: Wear Your Device\n\nPlace your CareBand Microcontroller Health Monitor device into the provided case. Then, attach the case to your wrist or arm, whichever is preferable for you.\n\nStep 8: Enjoy!\n\nYou are now ready to enjoy the benefits of your CareBand Microcontroller Health Monitor device. Use the app to monitor your health metrics and stay informed about your well-being.\n\nIf you have any questions or need further assistance, please refer to the user manual or contact our customer support team for help.\n\nThank you for choosing CareBand! We hope our device helps you live a healthier and happier life.',
                  style: FlutterFlowTheme.of(context).titleSmall.override(
                        fontFamily: 'Montserrat',
                        letterSpacing: 0.0,
                      ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
